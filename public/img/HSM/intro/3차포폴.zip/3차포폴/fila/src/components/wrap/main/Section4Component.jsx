import React from 'react';

export default function Section4Component () {
    return (
        <section className='section4'>
            <div id="wrap">
                <div className="container">
                    <div className="gap">
                        <div className="title">
                            <ul>
                                <li>
                                    <h2>추천 스타일</h2>
                                    <p>더보기</p>
                                </li>
                            </ul>
                        </div>
                        <div className="content">
                            <div className="slide-view">
                                <div className="slide-wrap">
                                    <div className="slide slide1"><img src="" alt="" /></div>
                                    <div className="slide slide2"><img src="" alt="" /></div>
                                    <div className="slide slide3"><img src="" alt="" /></div>
                                    <div className="slide slide4"><img src="" alt="" /></div>
                                    <div className="slide slide5"><img src="" alt="" /></div>
                                    <div className="slide slide6"><img src="" alt="" /></div>
                                    <div className="slide slide7"><img src="" alt="" /></div>
                                    <div className="slide slide8"><img src="" alt="" /></div>
                                    <div className="slide slide9"><img src="" alt="" /></div>
                                    <div className="slide slide10"><img src="" alt="" /></div>
                                    <div className="slide slide11"><img src="" alt="" /></div>
                                    <div className="slide slide12"><img src="" alt="" /></div>
                                    <div className="slide slide13"><img src="" alt="" /></div>
                                    <div className="slide slide14"><img src="" alt="" /></div>
                                    <div className="slide slide15"><img src="" alt="" /></div>
                                    <div className="slide slide16"><img src="" alt="" /></div>
                                    <div className="slide slide17"><img src="" alt="" /></div>
                                    <div className="slide slide18"><img src="" alt="" /></div>
                                    <div className="slide slide19"><img src="" alt="" /></div>
                                    <div className="slide slide20"><img src="" alt="" /></div>
                                    <div className="slide slide21"><img src="" alt="" /></div>
                                    <div className="slide slide22"><img src="" alt="" /></div>
                                    <div className="slide slide23"><img src="" alt="" /></div>
                                    <div className="slide slide24"><img src="" alt="" /></div>
                                    <div className="slide slide25"><img src="" alt="" /></div>
                                    <div className="slide slide26"><img src="" alt="" /></div>
                                    <div className="slide slide27"><img src="" alt="" /></div>
                                    <div className="slide slide28"><img src="" alt="" /></div>
                                    <div className="slide slide29"><img src="" alt="" /></div>
                                    <div className="slide slide30"><img src="" alt="" /></div>
                                    <div className="slide slide31"><img src="" alt="" /></div>
                                    <div className="slide slide32"><img src="" alt="" /></div>
                                    <div className="slide slide33"><img src="" alt="" /></div>
                                    <div className="slide slide34"><img src="" alt="" /></div>
                                    <div className="slide slide35"><img src="" alt="" /></div>
                                    <div className="slide slide36"><img src="" alt="" /></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};
