import React from 'react';

export default function FooterComponent (){
    return (
        <footer id='footer'>
            
        </footer>
    );
};
