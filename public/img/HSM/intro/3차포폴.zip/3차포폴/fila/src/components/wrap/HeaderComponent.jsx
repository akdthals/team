import React from 'react';

export default function HeaderComponent () {
    return (
        <header id='header'>
            
        </header>
    );
};

