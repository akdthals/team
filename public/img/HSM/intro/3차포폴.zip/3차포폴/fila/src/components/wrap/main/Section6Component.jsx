import React from 'react';

export default function Section6Component () {
    return (
        <section className='section6'>
            
        </section>
    );
};

